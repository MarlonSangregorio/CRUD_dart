// ignore_for_file: prefer_const_constructors

import 'package:crud_dart/views/create.dart';
import 'package:crud_dart/views/read.dart';
import 'package:crud_dart/views/delete.dart';
import 'package:crud_dart/views/update.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);




  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CRUD',
       routes: <String, WidgetBuilder>{
      '/createpage' : (BuildContext context) => CreatePage(),
      '/readpage' : (BuildContext context) => ReadPage(),
      '/deletepage' : (BuildContext context) => DeletePage(),
      '/updatepage' : (BuildContext context) => UpdatePage(),
       },
      theme: ThemeData(

        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color.fromARGB(255, 255, 255, 255)
      ),
      home: const MyHomePage(title: 'PROJETO CRUD'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      appBar: AppBar(
        
        title: Text(widget.title),
      ),
      body:
    
      Center(

        child: SizedBox(
          

          width: 250,
          height: 250,
          
          child: Column(
                    
          children: <Widget>  
          [
            
            Row(      
            children:     
             // ignore: prefer_const_literals_to_create_immutables, prefer_const_constructors
 
             // ignore: prefer_const_literals_to_create_immutables
             //BOTÃO CREATE
             [SizedBox     
             (
              width: 100,
              height: 100,
              
              child: ElevatedButton( onPressed:(){
                
              Navigator.pushNamed(context, '/createpage');

                
              } ,child: Text("Create"),
              )
              ),
              Padding(padding: EdgeInsets.all(16)),
              //BOTÃO READ
              SizedBox(
                width: 100,
                height: 100,
                child: ElevatedButton(onPressed:(){

                  Navigator.pushNamed(context, '/readpage');

                },child: Text("Read"),)
                
              )
              ],
          ),
            Padding(padding: EdgeInsets.all(16)),
            Row(
            children:

            //BOTÃO UPDATE

             // ignore: prefer_const_literals_to_create_immutables, prefer_const_constructors
             [SizedBox
             (
              width: 100,
              height: 100,
              child: ElevatedButton(onPressed: (){

             Navigator.pushNamed(context, '/updatepage');

              }
              ,child: Text("Update")
              )
              ),
              Padding(padding: EdgeInsets.all(16)),
             
             //BOTÃO DELETE

              SizedBox(
                width: 100,
                height: 100,
                child: ElevatedButton(onPressed: () { 

              Navigator.pushNamed(context, '/deletepage');

                },child: Text("Delete"),)
              )
              
              ],
              
          )
         
          ],
        
        )
        
        

        ),
      ),// This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
