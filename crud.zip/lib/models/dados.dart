class Dados {
  static List<String>? textos;
}