import "package:flutter/material.dart";
import "package:crud_dart/models/dados.dart";

class ReadPage extends StatefulWidget {
  const ReadPage({super.key});

  @override
  ReadPageState createState() {
    return ReadPageState();
  }
}

class ReadPageState extends State<ReadPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Read")), body: createList());
  }

  Widget createList() {
    if (Dados.textos?.isEmpty ?? true) {
      return const Center(child: Text("Sem Dados"));
    }

    return ListView.builder(
        itemCount: Dados.textos?.length,
        itemBuilder: (BuildContext context, int index) {
          return Center(child: Text(Dados.textos![index]));
        });
  }
}