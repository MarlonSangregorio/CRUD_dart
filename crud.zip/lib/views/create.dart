import "package:flutter/material.dart";
import "package:crud_dart/models/dados.dart";

class CreatePage extends StatefulWidget {
  const CreatePage({super.key});

  @override
  CreatePageState createState() {
    return CreatePageState();
  }
}

class CreatePageState extends State<CreatePage> {
  final _formUniqueKey = GlobalKey<FormState>();

  TextEditingController textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Create")),
        body: Form(
            key: _formUniqueKey,
            child: Column(children: [
              TextFormField(controller: textController),
              ElevatedButton(
                  onPressed: () {
                    if (Dados.textos == null) {
                      Dados.textos = [];
                    }
                    Dados.textos?.add(textController.text);
                  },
                  child: const Text("Enviar"))
            ])));
  }
}