import 'package:flutter/material.dart';
import 'package:crud_dart/models/dados.dart';

class DeletePage extends StatefulWidget {
  const DeletePage({super.key});

  @override
  DeletePageState createState() {
    return DeletePageState();
  }
}

class DeletePageState extends State<DeletePage> {
  final _formUniqueKey = GlobalKey<FormState>();

  TextEditingController tec = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Delete")),
        body: Center(
          child: Form(
              key: _formUniqueKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: tec,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        int leId = int.parse(tec.text);
                        String removido = Dados.textos!.removeAt(leId);
                        if (removido != "") {
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("$removido removido!")));
                        }
                      },
                      child: const Text("Deletar"))
                ],
              )),
        ));
  }
}