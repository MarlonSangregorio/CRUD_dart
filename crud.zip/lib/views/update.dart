import 'package:flutter/material.dart';
import 'package:crud_dart/models/dados.dart';

class UpdatePage extends StatefulWidget {
  const UpdatePage({super.key});

  @override
  UpdatePageState createState() {
    return UpdatePageState();
  }
}

class UpdatePageState extends State<UpdatePage> {
  final _formUniqueKey = GlobalKey<FormState>();

  TextEditingController tec_id = TextEditingController();
  TextEditingController tec_valor = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Update")),
        body: Center(
          child: Form(
              key: _formUniqueKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: tec_id,
                  ),
                  TextFormField(
                    controller: tec_valor,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        int _id = int.parse(tec_id.text);
                        Dados.textos![_id] = tec_valor.text;
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("${tec_valor.text} Foi atualizado com sucesso!",
                        textAlign: TextAlign.center), backgroundColor: Color.fromARGB(255, 0, 113, 205),));
                      },
                      child: const Text("Deletar"))
                ],
              )),
        ));
  }
}

/**final snackBar = SnackBar(
  content: Text('Você já avaliou o prato hoje, Obrigado!',
      textAlign: TextAlign.center),
  backgroundColor: Colors.green,
); */